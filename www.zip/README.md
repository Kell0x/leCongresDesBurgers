Je dirais qu'il n'y a pas de bon ou de mauvais burger, je dirais, si je dois
résumer ma vie avec vous aujourd'hui, je commencerais tout d'abord par des
rencontres, des gens qui m'ont tendu la main, peut-être à un moment où je ne
pouvais pas, où j'étais seul chez moi, et c'est assez curieux de se dire que le
hasard, les rencontres, forgent une destinée parce que, quand on a le gout du
burger, quand on a le gout du burger bien fait, le beau burger, parfois, on ne
trouve pas l'interlocuteur en face, je dirais, le miroir qui vous aide à
avancer ; alors ce n'est pas mon cas comme je le disais là, parce que moi j'ai
pu ; et je dis merci, je chante la vie, je mange la vie, je ne suis que burger
et finalement quand beaucoup de gens aujourd'hui me disent : mais comment fait-
tu pour avoir ce cholestérol ; et bien je leur répond très simplement, je leur
dis que c'est ce gout du burger, ce gout qui m'a poussé aujourd'hui à
entreprendre un développement web, mais demain qui sait, peut-être simplement à
me mettre au service du congrès, à faire le don, le don de soi...

Ce soir, et cette nuit, je dirais que le but, plus précisément l'ambition,
bien que modeste, consiste en la création, la mise en place, à disposition, d'un
site, d'une plateforme, sur laquelle, accessible, un jeu, un amusement, une
broutille. Cette broutille, ce jeu, plus qu'un jeu, c'est aussi un avertissement
pour tous, une mise en garde. Au travers de ce jeu, découvrez un danger, un
risque, un péril.

# Konami Code is Alive
